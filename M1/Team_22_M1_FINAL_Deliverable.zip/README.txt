T22_M1_D1_Tool_Policy.docx --- Team tool/software guidelines
T22_M1_D1_Tool_Policy.pdf --- Team tool/software guidelines
T22_M1_D2_Communication_Policy.docx --- Team communication guidelines
T22_M1_D2_Communication_Policy.pdf --- Team communication guidelines
T22_M1_D3_Version_Control_Policy.docx --- File version management guidlines
T22_M1_D3_Version_Control_Policy.pdf --- File version management guidlines
T22_M1_D4_Task_Policy.docx --- Task policy management procedures
T22_M1_D4_Task_Policy.pdf --- Task policy management procedures
T22_M1_D4_Task_Policy_Template.xlsx --- Example of the task policy template
T22_M1_D5_Team_Liaison.docx --- Names our team liaison
T22_M1_D5_Team_Liaison.pdf --- Names our team liaison